package com.example.GitHubUser

import android.content.ContentValues
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.GitHubUser.database.FavoriteHelper
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.CONTENT_URI
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.NAME
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.FOLLOWING
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.FOLLOWER
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.AVATAR
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.USERNAME
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.DETAIL
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.LOCATION
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.COMPANY
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.FAVORITE
import com.example.GitHubUser.databinding.ActivityDetailBinding
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.item_row_user.tvName
import kotlin.math.log


class DetailActivity : AppCompatActivity(), View.OnClickListener {


    private lateinit var favHelper: FavoriteHelper
    private var favorite: User? = null
    private lateinit var avatarUser: String
    private var isFav = false
    private lateinit var binding: ActivityDetailBinding

    //val favBtn = findViewById<ImageButton>(R.id.fav_add)


    companion object{

        const val EXTRA_USER = "extra_user"
        const val EXTRA_FAV = "extra_fav"
        const val EXTRA_DB = "extra_db"
        const val EXTRA_POSITION = "extra_position"
        private val TAG = DetailActivity::class.java.simpleName


        @StringRes
        private val TAB_TITLES = intArrayOf(

            R.string.tab_text_2,
            R.string.tab_text_3
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)



        val sectionPageAdapter = SectionPageAdapter(this)
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionPageAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) {tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        supportActionBar?.elevation = 0f


        favHelper = FavoriteHelper.getInstance(applicationContext)
        favHelper.open()
        favorite = intent.getParcelableExtra(EXTRA_DB)

        if(favorite == null){
            setDataAPI()
        }else{
            setDataObject()
            isFav = true
            val unChecked: Int = R.drawable.ic_baseline_favorite_border_36
            binding.favAdd.setImageResource(unChecked)
        }

        binding.favAdd.setOnClickListener(this)

//        val intent = intent.getParcelableExtra<User>(EXTRA_USER) as User


//        val textUserName = intent.userName
//        val textName = intent.name
//        val textDetail = "Location: ${ intent.detail }"
//        val textFollower = "Follower: ${intent.follower}"
//        val textFollowing = "Following: ${intent.following}"
//        val textLocation = "Company: ${intent.location}"
//        val textCompany = "Repositories: ${intent.company}"
//
//
//        val tvDataName: TextView = findViewById(R.id.tv_user_name)
//        val tvDataFollowing: TextView = findViewById(R.id.tv_user_following)
//        val tvDataFollower: TextView = findViewById(R.id.tv_user_follower)
//        val ivDataPhoto: ImageView = findViewById(R.id.img_photo)
//        val tvDataUserName: TextView = findViewById(R.id.tv_user_userName)
//        val tvDataDetail: TextView = findViewById(R.id.tv_user_detail)
//        val tvDataLocation: TextView = findViewById(R.id.tv_user_location)
//        val tvDataCompany: TextView = findViewById(R.id.tv_user_company)
//
//
//        Glide.with(this)
//                .load(intent?.avatar)
//                .apply(RequestOptions().override(350, 350))
//                .into(ivDataPhoto)
//
//
//
//        tvDataName.text = textName
//        tvDataFollowing.text = textFollowing
//        tvDataFollower.text = textFollower
//        tvDataUserName.text = textUserName
//        tvDataDetail.text = textDetail
//        tvDataLocation.text = textLocation
//        tvDataCompany.text = textCompany
    }


    private fun setDataAPI() {
        val user = intent.getParcelableExtra(EXTRA_USER) as User
        setTitle(user.name.toString())
        tv_user_name.text = user.name.toString()
        tv_user_following.text = user.following.toString()
        tv_user_follower.text = user.follower.toString()
        avatarUser = user.avatar.toString()
        tv_user_userName.text = user.userName.toString()
        tv_user_detail.text = user.detail.toString()
        tv_user_location.text = user.location.toString()
        tv_user_company.text = user.company.toString()
        Glide.with(this)
            .load(user.avatar.toString())
            .into(img_photo)

    }

    private fun setDataObject(){
        val favUser = intent.getParcelableExtra(EXTRA_DB) as User
        setTitle(favUser.name.toString())
        tv_user_name.text = favUser.name.toString()
        tv_user_following.text = favUser.following.toString()
        tv_user_follower.text = favUser.follower.toString()
        avatarUser = favUser.avatar.toString()
        tv_user_userName.text = favUser.userName.toString()
        tv_user_detail.text = favUser.detail.toString()
        tv_user_location.text = favUser.location.toString()
        tv_user_company.text = favUser.company.toString()
        Glide.with(this)
            .load(favUser.avatar.toString())
            .into(img_photo)
    }

    override fun onClick(v: View) {
        val fav: Int = R.drawable.ic_baseline_favorite_black_36
        val unFav: Int = R.drawable.ic_baseline_favorite_border_36
        if(v.id == R.id.fav_add){
            if(isFav){
                Log.d(TAG, "onCLick: $isFav, ${favorite?.name}")
                favHelper.delete(favorite?.name.toString())
                Toast.makeText(this, "unFavorite User", Toast.LENGTH_SHORT).show()
                binding.favAdd.setImageResource(unFav)
                isFav = false
                finish()


            }else{
                val name = tv_user_name.text.toString()
                val following = tv_user_following.text.toString()
                val follower = tv_user_follower.text.toString()
                val avatar = avatarUser
                val userName = tv_user_userName.text.toString()
                val detail = tv_user_detail.text.toString()
                val company = tv_user_company.text.toString()
                val location = tv_user_location.text.toString()
                val favorite = 1

                val values = ContentValues()

                values.put(NAME, name)
                values.put(FOLLOWING, following)
                values.put(FOLLOWER, follower)
                values.put(AVATAR, avatar)
                values.put(USERNAME, userName)
                values.put(DETAIL,detail)
                values.put(COMPANY, company)
                values.put(LOCATION, location)
                values.put(FAVORITE, favorite)

                isFav = true
                contentResolver.insert(CONTENT_URI, values)
                Toast.makeText(this, "Added to Favorite", Toast.LENGTH_SHORT).show()
                binding.favAdd.setImageResource(fav)

            }
        }
    }
}