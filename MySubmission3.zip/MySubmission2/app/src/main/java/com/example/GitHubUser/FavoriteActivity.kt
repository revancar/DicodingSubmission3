package com.example.GitHubUser

import android.content.Intent
import android.database.ContentObserver
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.PersistableBundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.GitHubUser.databinding.ActivityFavoriteBinding
import com.example.GitHubUser.database.DatabaseContract.UserColumns.Companion.CONTENT_URI
import com.example.GitHubUser.helper.MappingHelper
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class FavoriteActivity : AppCompatActivity() {

    private lateinit var adapter: FavoriteAdapter
    private lateinit var binding: ActivityFavoriteBinding
    private val list = ArrayList<User>()

    companion object{
        private const val EXTRA_STATE = "extra_state"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvUser.layoutManager = LinearLayoutManager(this)
        adapter = FavoriteAdapter(this)
        binding.rvUser.adapter = adapter

        binding.rvUser.setHasFixedSize(true)

        val handlerThread = HandlerThread("DataObserver")
        handlerThread.start()
        val handler = Handler(handlerThread.looper)

        val myObserver = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                loadUserAsync()
            }
        }

        contentResolver.registerContentObserver(CONTENT_URI, true, myObserver)

        if (savedInstanceState == null){
            loadUserAsync()
        }else{
            val list = savedInstanceState.getParcelableArrayList<User>(EXTRA_STATE)
            if (list != null){
                adapter.userList = list
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putParcelableArrayList(EXTRA_STATE, adapter.userList)
    }

    private fun loadUserAsync(){
        GlobalScope.launch(Dispatchers.Main) {
            binding.progressBar.visibility = View.VISIBLE
            val defferedUser = async (Dispatchers.IO){
                val cursor = contentResolver?.query(CONTENT_URI, null, null, null, null)
                MappingHelper.mapCursorToArrayList(cursor)
            }
            val userData = defferedUser.await()
            binding.progressBar.visibility = View.INVISIBLE
            if(userData.size > 0){
                adapter.userList = userData
            }else{
                adapter.userList = ArrayList()
                showSnackBarMessage()
            }
        }
    }

    private fun showSnackBarMessage(){
        Snackbar.make(binding.rvUser, "Tidak ada data saat ini", Snackbar.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        loadUserAsync()
    }

    private fun showSelectedUser(user: User){
        User(
                user.name,
                user.following,
                user.follower,
                user.avatar,
                user.userName,
                user.detail,
                user.location,
                user.company,
                user.repositories

        )


        val intent = Intent(this@FavoriteActivity, DetailActivity::class.java)
        intent.putExtra(DetailActivity.EXTRA_USER, user)
        startActivity(intent)
    }

}