package com.example.GitHubUser


import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import com.example.GitHubUser.databinding.ActivitySettingBinding
import java.util.*


class SettingActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var alarmReceiver: AlarmBroadcastReceiver
    private lateinit var binding: ActivitySettingBinding

    companion object{
        const val PREFS_NAME = "user_pref"
        private const val TYPE_REPEATING = "Repeating Alarm"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        alarmReceiver = AlarmBroadcastReceiver()

        toggleSwitch()
        binding.switchNotif.setOnCheckedChangeListener{_, isChecked ->
            if (isChecked){
                alarmReceiver.setRepeatingAlarm(this, AlarmBroadcastReceiver.TYPE_REPEATING, getString(R.string.notif_setUp))
            }else{
                alarmReceiver.cancelRepeatingAlarm(this)
            }
            saveAlarm(isChecked)
        }

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) finish()
        return super.onOptionsItemSelected(item)
    }

    private fun toggleSwitch(){
        binding.switchNotif.isChecked = sharedPreferences.getBoolean(TYPE_REPEATING, false)
    }

    private fun saveAlarm(value: Boolean){
        val editor = sharedPreferences.edit()
        editor.putBoolean(TYPE_REPEATING, value)
        editor.apply()
    }
}