package com.example.GitHubUser

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class User(
    var name: String? = "",
    var following: String ? = "",
    var follower: String ? = "",
    var avatar: String? = "",
    var userName: String? = "",
    var detail: String? = "",
    var location: String? = "",
    var company: String? = "",
    var repositories: String? = "",
    var Fav: String? = "0"

) : Parcelable