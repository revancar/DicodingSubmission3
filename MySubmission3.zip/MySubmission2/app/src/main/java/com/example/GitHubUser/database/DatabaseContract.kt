package com.example.GitHubUser.database

import android.provider.BaseColumns
import android.net.Uri

object DatabaseContract {

    const val AUTH = "com.example.GitHubUser"
    const val SCHEME = "content"

    internal class UserColumns : BaseColumns{
        companion object{
            const val TABLE_NAME = "Favorite"
            const val NAME = "name"
            const val FOLLOWING = "following"
            const val FOLLOWER = "follower"
            const val AVATAR = "avatar"
            const val USERNAME = "username"
            const val DETAIL = "detail"
            const val LOCATION = "location"
            const val COMPANY = "company"
            const val REPOSITORIES = "repositories"
            const val FAVORITE = "Fav"


            val CONTENT_URI: Uri = android.net.Uri.Builder().scheme(SCHEME)
                .authority(AUTH)
                .appendPath(TABLE_NAME)
                .build()
        }
    }

}