package com.example.GitHubUser.helper

import android.database.Cursor
import com.example.GitHubUser.User
import com.example.GitHubUser.database.DatabaseContract

object MappingHelper {

    fun mapCursorToArrayList(userCursor: Cursor?): ArrayList<User> {
        val userList = ArrayList<User>()

        userCursor?.apply {
            while (moveToNext()){
                val name = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.NAME))
                val following = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.FOLLOWING))
                val follower = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.FOLLOWER))
                val avatar = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.AVATAR))
                val username = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.USERNAME))
                val detail = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.DETAIL))
                val location = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.LOCATION))
                val company = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.COMPANY))
                val repositories = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.REPOSITORIES))
                val fav = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.FAVORITE))
                userList.add(User(name, following, follower, avatar, username, detail, location, company, repositories, fav))
            }
        }
        return userList
    }

}